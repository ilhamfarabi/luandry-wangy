

<?php $__env->startSection('content'); ?>
<h2>Daftar Pesanan</h2>
<a href="<?php echo e(route('pesanan.create')); ?>" class="btn btn-success mb-3">Tambah Pesanan</a>
<table class="table table-bordered">
  <tr>
    <th>ID</th>
    <th>Pelanggan</th>
    <th>Layanan</th>
    <th>Jumlah</th>
    <th>Total</th>
    <th>Status</th>
    <?php if(Auth::user()->role == 'admin'): ?>
      <th>Karyawan</th>
    <?php endif; ?>
    <th>Aksi</th>
  </tr>
  <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($p->id); ?></td>
    <td><?php echo e($p->nama_pelanggan); ?></td>
    <td><?php echo e($p->layanan->nama_layanan); ?></td>
    <td><?php echo e($p->jumlah); ?></td>
    <td>Rp<?php echo e($p->total_harga); ?></td>
    <td><?php echo e($p->status); ?></td>
    <?php if(Auth::user()->role == 'admin'): ?>
      <td><?php echo e($p->user->name); ?></td>
    <?php endif; ?>
    <td>
      <a href="<?php echo e(route('pesanan.edit',$p->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
      <form action="<?php echo e(route('pesanan.destroy',$p->id)); ?>" method="POST" style="display:inline">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger btn-sm">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry-app\resources\views/pesanan/index.blade.php ENDPATH**/ ?>