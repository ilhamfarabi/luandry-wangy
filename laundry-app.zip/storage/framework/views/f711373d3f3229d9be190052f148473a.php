

<?php $__env->startSection('content'); ?>
<h2>Edit Karyawan</h2>
<form action="<?php echo e(route('karyawan.update',$karyawan->id)); ?>" method="POST">
  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <div class="mb-3">
    <label>Nama</label>
    <input type="text" name="nama" class="form-control" value="<?php echo e($karyawan->nama); ?>">
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" class="form-control" value="<?php echo e($karyawan->email); ?>">
  </div>
  <div class="mb-3">
    <label>Telepon</label>
    <input type="text" name="telepon" class="form-control" value="<?php echo e($karyawan->telepon); ?>">
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry-app\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>