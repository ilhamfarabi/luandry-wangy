

<?php $__env->startSection('content'); ?>
<h2>Buat Pesanan</h2>
<form action="<?php echo e(route('pesanan.store')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label>Nama Pelanggan</label>
    <input type="text" name="nama_pelanggan" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Layanan</label>
    <select name="layanan_id" class="form-control">
      <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($l->id); ?>"><?php echo e($l->nama_layanan); ?> - Rp<?php echo e($l->harga); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="mb-3">
    <label>Jumlah</label>
    <input type="number" name="jumlah" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry-app\resources\views/pesanan/create.blade.php ENDPATH**/ ?>