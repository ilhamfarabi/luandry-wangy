

<?php $__env->startSection('content'); ?>
<h2>Edit Pesanan</h2>
<form action="<?php echo e(route('pesanan.update',$pesanan->id)); ?>" method="POST">
  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <div class="mb-3">
    <label>Nama Pelanggan</label>
    <input type="text" name="nama_pelanggan" class="form-control" value="<?php echo e($pesanan->nama_pelanggan); ?>">
  </div>
  <div class="mb-3">
    <label>Layanan</label>
    <select name="layanan_id" class="form-control">
      <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($l->id); ?>" <?php echo e($pesanan->layanan_id==$l->id ? 'selected':''); ?>>
          <?php echo e($l->nama_layanan); ?> - Rp<?php echo e($l->harga); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="mb-3">
    <label>Jumlah</label>
    <input type="number" name="jumlah" class="form-control" value="<?php echo e($pesanan->jumlah); ?>">
  </div>
  <div class="mb-3">
    <label>Status</label>
    <select name="status" class="form-control">
      <option value="pending" <?php echo e($pesanan->status=='pending'?'selected':''); ?>>Pending</option>
      <option value="proses" <?php echo e($pesanan->status=='proses'?'selected':''); ?>>Proses</option>
      <option value="selesai" <?php echo e($pesanan->status=='selesai'?'selected':''); ?>>Selesai</option>
    </select>
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry-app\resources\views/pesanan/edit.blade.php ENDPATH**/ ?>