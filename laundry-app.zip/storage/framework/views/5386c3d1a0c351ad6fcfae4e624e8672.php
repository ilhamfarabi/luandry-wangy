

<?php $__env->startSection('content'); ?>
<h2>Tambah Layanan</h2>
<form action="<?php echo e(route('layanan.store')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label>Nama Layanan</label>
    <input type="text" name="nama_layanan" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Harga</label>
    <input type="number" step="0.01" name="harga" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry-app\resources\views/layanan/create.blade.php ENDPATH**/ ?>