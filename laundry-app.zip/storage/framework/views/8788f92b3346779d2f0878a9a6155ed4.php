

<?php $__env->startSection('content'); ?>
<h2>Data Karyawan</h2>
<a href="<?php echo e(route('karyawan.create')); ?>" class="btn btn-success mb-3">Tambah Karyawan</a>
<table class="table table-bordered">
  <tr>
    <th>ID</th><th>Nama</th><th>Email</th><th>Telepon</th><th>Aksi</th>
  </tr>
  <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($k->id); ?></td>
    <td><?php echo e($k->nama); ?></td>
    <td><?php echo e($k->email); ?></td>
    <td><?php echo e($k->telepon); ?></td>
    <td>
      <a href="<?php echo e(route('karyawan.edit',$k->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
      <form action="<?php echo e(route('karyawan.destroy',$k->id)); ?>" method="POST" style="display:inline">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger btn-sm">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laundry-app\resources\views/karyawan/index.blade.php ENDPATH**/ ?>