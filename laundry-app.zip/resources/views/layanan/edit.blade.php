@extends('layouts.app')

@section('content')
<h2>Edit Layanan</h2>
<form action="{{ route('layanan.update',$layanan->id) }}" method="POST">
  @csrf @method('PUT')
  <div class="mb-3">
    <label>Nama Layanan</label>
    <input type="text" name="nama_layanan" class="form-control" value="{{ $layanan->nama_layanan }}">
  </div>
  <div class="mb-3">
    <label>Harga</label>
    <input type="number" step="0.01" name="harga" class="form-control" value="{{ $layanan->harga }}">
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
</form>
@endsection
