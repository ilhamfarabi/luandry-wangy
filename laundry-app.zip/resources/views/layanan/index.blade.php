@extends('layouts.app')

@section('content')
<h2>Data Layanan</h2>
<a href="{{ route('layanan.create') }}" class="btn btn-success mb-3">Tambah Layanan</a>
<table class="table table-bordered">
  <tr>
    <th>ID</th><th>Nama Layanan</th><th>Harga</th><th>Aksi</th>
  </tr>
  @foreach($layanans as $l)
  <tr>
    <td>{{ $l->id }}</td>
    <td>{{ $l->nama_layanan }}</td>
    <td>Rp{{ $l->harga }}</td>
    <td>
      <a href="{{ route('layanan.edit',$l->id) }}" class="btn btn-warning btn-sm">Edit</a>
      <form action="{{ route('layanan.destroy',$l->id) }}" method="POST" style="display:inline">
        @csrf @method('DELETE')
        <button class="btn btn-danger btn-sm">Hapus</button>
      </form>
    </td>
  </tr>
  @endforeach
</table>
@endsection
