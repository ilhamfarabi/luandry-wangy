@extends('layouts.app')

@section('content')
<h2>Tambah Karyawan</h2>
<form action="{{ route('karyawan.store') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label>Nama</label>
    <input type="text" name="nama" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Telepon</label>
    <input type="text" name="telepon" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>
@endsection
