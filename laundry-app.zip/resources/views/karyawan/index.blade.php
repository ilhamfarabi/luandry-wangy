@extends('layouts.app')

@section('content')
<h2>Data Karyawan</h2>
<a href="{{ route('karyawan.create') }}" class="btn btn-success mb-3">Tambah Karyawan</a>
<table class="table table-bordered">
  <tr>
    <th>ID</th><th>Nama</th><th>Email</th><th>Telepon</th><th>Aksi</th>
  </tr>
  @foreach($karyawans as $k)
  <tr>
    <td>{{ $k->id }}</td>
    <td>{{ $k->nama }}</td>
    <td>{{ $k->email }}</td>
    <td>{{ $k->telepon }}</td>
    <td>
      <a href="{{ route('karyawan.edit',$k->id) }}" class="btn btn-warning btn-sm">Edit</a>
      <form action="{{ route('karyawan.destroy',$k->id) }}" method="POST" style="display:inline">
        @csrf @method('DELETE')
        <button class="btn btn-danger btn-sm">Hapus</button>
      </form>
    </td>
  </tr>
  @endforeach
</table>
@endsection
