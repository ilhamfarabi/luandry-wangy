@extends('layouts.app')

@section('content')
<h2>Edit Karyawan</h2>
<form action="{{ route('karyawan.update',$karyawan->id) }}" method="POST">
  @csrf @method('PUT')
  <div class="mb-3">
    <label>Nama</label>
    <input type="text" name="nama" class="form-control" value="{{ $karyawan->nama }}">
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" class="form-control" value="{{ $karyawan->email }}">
  </div>
  <div class="mb-3">
    <label>Telepon</label>
    <input type="text" name="telepon" class="form-control" value="{{ $karyawan->telepon }}">
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
</form>
@endsection
