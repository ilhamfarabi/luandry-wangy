@extends('layouts.app')

@section('content')
<h2>Edit Pesanan</h2>
<form action="{{ route('pesanan.update',$pesanan->id) }}" method="POST">
  @csrf @method('PUT')
  <div class="mb-3">
    <label>Nama Pelanggan</label>
    <input type="text" name="nama_pelanggan" class="form-control" value="{{ $pesanan->nama_pelanggan }}">
  </div>
  <div class="mb-3">
    <label>Layanan</label>
    <select name="layanan_id" class="form-control">
      @foreach($layanans as $l)
        <option value="{{ $l->id }}" {{ $pesanan->layanan_id==$l->id ? 'selected':'' }}>
          {{ $l->nama_layanan }} - Rp{{ $l->harga }}
        </option>
      @endforeach
    </select>
  </div>
  <div class="mb-3">
    <label>Jumlah</label>
    <input type="number" name="jumlah" class="form-control" value="{{ $pesanan->jumlah }}">
  </div>
  <div class="mb-3">
    <label>Status</label>
    <select name="status" class="form-control">
      <option value="pending" {{ $pesanan->status=='pending'?'selected':'' }}>Pending</option>
      <option value="proses" {{ $pesanan->status=='proses'?'selected':'' }}>Proses</option>
      <option value="selesai" {{ $pesanan->status=='selesai'?'selected':'' }}>Selesai</option>
    </select>
  </div>
  <button type="submit" class="btn btn-primary">Update</button>
</form>
@endsection
