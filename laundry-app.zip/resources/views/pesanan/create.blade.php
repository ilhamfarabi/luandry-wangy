@extends('layouts.app')

@section('content')
<h2>Buat Pesanan</h2>
<form action="{{ route('pesanan.store') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label>Nama Pelanggan</label>
    <input type="text" name="nama_pelanggan" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Layanan</label>
    <select name="layanan_id" class="form-control">
      @foreach($layanans as $l)
        <option value="{{ $l->id }}">{{ $l->nama_layanan }} - Rp{{ $l->harga }}</option>
      @endforeach
    </select>
  </div>
  <div class="mb-3">
    <label>Jumlah</label>
    <input type="number" name="jumlah" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>
@endsection
