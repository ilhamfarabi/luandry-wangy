@extends('layouts.app')

@section('content')
<h2>Daftar Pesanan</h2>
<a href="{{ route('pesanan.create') }}" class="btn btn-success mb-3">Tambah Pesanan</a>
<table class="table table-bordered">
  <tr>
    <th>ID</th>
    <th>Pelanggan</th>
    <th>Layanan</th>
    <th>Jumlah</th>
    <th>Total</th>
    <th>Status</th>
    @if(Auth::user()->role == 'admin')
      <th>Karyawan</th>
    @endif
    <th>Aksi</th>
  </tr>
  @foreach($pesanans as $p)
  <tr>
    <td>{{ $p->id }}</td>
    <td>{{ $p->nama_pelanggan }}</td>
    <td>{{ $p->layanan->nama_layanan }}</td>
    <td>{{ $p->jumlah }}</td>
    <td>Rp{{ $p->total_harga }}</td>
    <td>{{ $p->status }}</td>
    @if(Auth::user()->role == 'admin')
      <td>{{ $p->user->name }}</td>
    @endif
    <td>
      <a href="{{ route('pesanan.edit',$p->id) }}" class="btn btn-warning btn-sm">Edit</a>
      <form action="{{ route('pesanan.destroy',$p->id) }}" method="POST" style="display:inline">
        @csrf @method('DELETE')
        <button class="btn btn-danger btn-sm">Hapus</button>
      </form>
    </td>
  </tr>
  @endforeach
</table>
@endsection
