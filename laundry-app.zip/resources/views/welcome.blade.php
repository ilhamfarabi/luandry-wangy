<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laundry Bersih & Wangi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero {
            background: url('https://images.unsplash.com/photo-1581579188871-45ea61f7d70b') center/cover no-repeat;
            color: white;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }
        .hero h1 { font-size: 3rem; font-weight: bold; }
        .hero p { font-size: 1.2rem; }
        .section-title { margin: 50px 0 30px; text-align: center; }
        footer {
            background: #343a40;
            color: white;
            padding: 20px 0;
            text-align: center;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <!-- Hero Section -->
    <section class="hero">
        <div>
            <h1>Laundry Bersih & Wangi</h1>
            <p>Solusi terbaik untuk cucian Anda, cepat, bersih, dan wangi.</p>
            <a href="{{ route('login') }}" class="btn btn-primary btn-lg">Pesan Sekarang</a>
        </div>
    </section>

    <!-- About Us -->
    <section class="container">
        <div class="section-title">
            <h2>Tentang Kami</h2>
            <p>Kami adalah penyedia layanan laundry profesional dengan pelayanan cepat, bersih, dan wangi.</p>
        </div>
        <div class="row text-center">
            <div class="col-md-4">
                <h4>Berpengalaman</h4>
                <p>Tim kami berpengalaman dalam layanan laundry lebih dari 5 tahun.</p>
            </div>
            <div class="col-md-4">
                <h4>Modern</h4>
                <p>Menggunakan mesin modern dan detergen ramah lingkungan.</p>
            </div>
            <div class="col-md-4">
                <h4>Terjangkau</h4>
                <p>Harga bersaing dengan kualitas terbaik.</p>
            </div>
        </div>
    </section>

    <!-- Services -->
    <section class="bg-light py-5">
        <div class="container">
            <div class="section-title">
                <h2>Layanan Kami</h2>
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <div class="card p-3 shadow-sm">
                        <h5>Cuci Kering</h5>
                        <p>Layanan cepat dan higienis, pakaian langsung siap dipakai.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 shadow-sm">
                        <h5>Cuci Setrika</h5>
                        <p>Pakaian Anda tidak hanya bersih, tapi juga rapi dan wangi.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 shadow-sm">
                        <h5>Setrika Saja</h5>
                        <p>Untuk Anda yang hanya butuh layanan setrika profesional.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact -->
    <section class="container py-5">
        <div class="section-title">
            <h2>Kontak Kami</h2>
            <p>Hubungi kami untuk layanan laundry cepat dan bersih.</p>
        </div>
        <div class="row text-center">
            <div class="col-md-4">
                <h5>Alamat</h5>
                <p>Jl. Mawar No. 123, Jakarta</p>
            </div>
            <div class="col-md-4">
                <h5>Telepon</h5>
                <p>0812-3456-7890</p>
            </div>
            <div class="col-md-4">
                <h5>Email</h5>
                <p>info@laundrybersih.com</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; {{ date('Y') }} Laundry Bersih & Wangi. All rights reserved.</p>
    </footer>

</body>
</html>
